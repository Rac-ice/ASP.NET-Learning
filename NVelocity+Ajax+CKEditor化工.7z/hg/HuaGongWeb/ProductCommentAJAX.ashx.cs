﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.Script.Serialization;

namespace HuaGongWeb
{
    /// <summary>
    /// ProductCommentAJAX 的摘要说明
    /// </summary>
    public class ProductCommentAJAX : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            string action = context.Request["Action"];
            if (action == "PostComment")
            {
                long productId = Convert.ToInt64(context.Request["ProductId"]);
                string title = context.Request["Title"];
                string msg = context.Request["Msg"];
                //内容是网友提交的，要对数据的安全性、合法性等做充足的检测。
                if (title.Contains(">") || title.Contains("<")
                    || msg.Contains(">") || msg.Contains("<"))
                {
                    context.Response.Write("error");
                    return;
                }

                SqlHelper.ExecuteNonQuery("Insert into T_ProductComments(ProductId,Title,Msg,CreateDateTime) values(@ProductId,@Title,@Msg,getdate())",
                new SqlParameter("@ProductId", productId), new SqlParameter("@Title", title),
                new SqlParameter("@Msg",msg));
                context.Response.Write("ok");
            }
            else if (action == "Load")
            {
                long productId = Convert.ToInt64(context.Request["ProductId"]);
                DataTable dt = SqlHelper.ExecuteDataTable("select * from T_ProductComments where ProductId=@Id",new SqlParameter("@Id",productId));
                //一般不要把DataTable等对象直接通过Json传递给客户端，一般应该值传递基本类型或者POCO（Plain Object C# Object，简单的类，只有属性的类）或者是POCO的简单结合
                object[] comments = new object[dt.Rows.Count];
                for (int i = 0; i < comments.Length; i++)
                {
                    DataRow row = dt.Rows[i];
                    DateTime createDT = (DateTime)row["CreateDateTime"];
                    comments[i] = new { Title = row["Title"], Msg = row["Msg"], CreateDateTime = createDT.ToString() };
                }
                string json = new JavaScriptSerializer().Serialize(comments);
                context.Response.Write(json);
            }
            else
            {
                context.Response.Write("Action错误！");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}