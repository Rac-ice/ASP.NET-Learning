﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace HuaGongWeb
{
    /// <summary>
    /// ProductList 的摘要说明
    /// </summary>
    public class ProductList : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            int pageNum = 1;
            if (context.Request["PageNum"] != null)
            {
                pageNum = Convert.ToInt32(context.Request["PageNum"]);
            }

            DataTable products;

            //如果指定了CategoryId参数，则只显示特定类型的产品
            //如果没有指定，则显示所有产品
            bool hasCategoryId = !string.IsNullOrEmpty(context.Request["CategoryId"]);
            if (hasCategoryId)
            {
                long categoryId = Convert.ToInt64(context.Request["CategoryId"]);
                products = SqlHelper.ExecuteDataTable("select * from (select *,row_number() over(order by p.Id asc) as num from T_Products p where p.CategoryId=@CategoryId) s where s.num between @Start and @End", new SqlParameter("@CategoryId", categoryId),
                    new SqlParameter("@Start", (pageNum - 1) * 9 + 1)
                , new SqlParameter("@End", pageNum * 9));
            }
            else
            {
                products = SqlHelper.ExecuteDataTable("select * from (select *,row_number() over(order by p.Id asc) as num from T_Products p) s where s.num between @Start and @End", new SqlParameter("@Start", (pageNum - 1) * 9 + 1)
                , new SqlParameter("@End", pageNum * 9));
            }

            int totalCount;
            if (hasCategoryId)
            {
                long categoryId = Convert.ToInt64(context.Request["CategoryId"]);
                totalCount = (int)SqlHelper.ExecuteScalar("select count(*) from T_Products where CategoryId=@CategoryId", new SqlParameter("@CategoryId", categoryId));
            }
            else
            {
                totalCount = (int)SqlHelper.ExecuteScalar("select count(*) from T_Products");
            }
            int pageCount = (int)Math.Ceiling(totalCount / 9.0);
            object[] pageData = new object[pageCount];
            for (int i = 0; i < pageCount; i++)
            {
                pageData[i] = new { Href="ProductList.ashx?PageNum="+(i+1),Title=i+1};
            }

            var data = new { Products = products.Rows, PageData = pageData, TotalCount = totalCount, PageNum = pageNum, PageCount = pageCount, ProductCategories = CommonHelper.GetProductCategories(), Settings = CommonHelper.GetSettings() };
            string html = CommonHelper.RenderHtml("Front/ProductList.htm", data);
            context.Response.Write(html);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}