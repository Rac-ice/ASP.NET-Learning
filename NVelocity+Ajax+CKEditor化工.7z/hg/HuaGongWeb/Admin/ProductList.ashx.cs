﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.SessionState;

namespace HuaGongWeb.Admin
{
    /// <summary>
    /// ProductList 的摘要说明
    /// </summary>
    public class ProductList : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";

            AdminHelper.CheckLogin();
            //todo:检查PageNum合法性
            int pageNum=1;
            //如果没有传递PageNum参数，则默认为第1页
            if (context.Request["PageNum"] != null)
            {
                pageNum = Convert.ToInt32(context.Request["PageNum"]);
            }           

            //DataTable products = SqlHelper.ExecuteDataTable("select p.Id as Id,p.Name as Name,c.Name as CategoryName from T_Products p left join T_ProductCategories c on p.CategoryId=c.Id");

            DataTable products = SqlHelper.ExecuteDataTable(@"select * from
(
select p.Id as Id,p.Name as Name,c.Name as CategoryName, 
row_number() over (order by p.Id asc) as num 
from T_Products p 
left join T_ProductCategories c on p.CategoryId=c.Id
) as s
where s.num between @Start and @End", 
                                    new SqlParameter("@Start", (pageNum - 1) * 10 + 1),
                                    new SqlParameter("@End",pageNum*10));

            
            //第1页：between 1 and 10，第2页between 11 and 20
            //3:21 and 30
            //第pageNum页就是：(pageNum-1)*10+1 and pageNum*10

            //不能一次性把T_ProductCategories表中的数据都取出来，否则性能很差
            //也不能一次性取出来，然后用C#过滤。

//            select * from
//(
//select p.Id as Id,p.Name as Name,c.Name as CategoryName, 
//row_number() over (order by p.Id asc) as num 
//from T_Products p 
//left join T_ProductCategories c on p.CategoryId=c.Id
//) as s
//where s.num between 3 and 5


            //总条数是n：页数=Ceiling(n/10)。天花板函数是一个>=这个数的一个最小的整数
            int totalCount = (int)SqlHelper.ExecuteScalar("select count(*) from T_Products");
            //总页数
            int pageCount = (int)Math.Ceiling(totalCount / 10.0);
            object[] pageData = new object[pageCount];
            for (int i = 0; i < pageCount; i++)
            {
                pageData[i] = new { Href = "ProductList.ashx?PageNum="+(i+1),Title=(i+1) };
            }

            var data = new { Title = "产品列表", Products = products.Rows, PageData = pageData };
            string html = CommonHelper.RenderHtml("Admin/ProductList.htm", data);
            context.Response.Write(html);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}