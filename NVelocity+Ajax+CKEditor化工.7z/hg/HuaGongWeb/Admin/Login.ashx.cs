﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.SessionState;

namespace HuaGongWeb.Admin
{
    /// <summary>
    /// Login 的摘要说明
    /// </summary>
    public class Login : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            bool isLogin = !string.IsNullOrEmpty(context.Request["Login"]);
            if (isLogin)
            {
                string username = context.Request["UserName"];
                string password = context.Request["Password"];
                int count = (int)SqlHelper.ExecuteScalar("select count(*) from T_SysUsers where Name=@UserName and Password=@Password", new SqlParameter("@UserName", username)
                    , new SqlParameter("@Password", password));
                if (count == 1)
                {
                    //context.Response.Write("登录成功");
                    //把登录信息记录到Session中，并且转向后台首页(自己开发一个Index.ashx)
                    context.Session["LoginUserName"] = username;
                    context.Response.Redirect("Settings.ashx");
                }
                else if (count > 1)
                {
                    context.Response.Write("严重问题，出现重复数据");
                }
                else
                {
                    context.Response.Write("用户名或者密码错误！");
                }
            }
            else
            {
                var html = CommonHelper.RenderHtml("Admin/login.htm", null);
                context.Response.Write(html);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}