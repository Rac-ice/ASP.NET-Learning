﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HuaGongWeb.Admin
{
    public class AdminHelper
    {
        /// <summary>
        /// 检查有没有后台登录，如果没有的话，重定向到Login.ashx
        /// </summary>
        //public static void CheckLogin(HttpContext context)
        public static void CheckLogin()
        {
            HttpContext context = HttpContext.Current;
            if (context.Session["LoginUserName"] == null)
            {
                context.Response.Redirect("Login.ashx");
            }
        }
    }
}