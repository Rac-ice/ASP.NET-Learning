﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.SessionState;

namespace HuaGongWeb.Admin
{
    /// <summary>
    /// SysUserList 的摘要说明
    /// </summary>
    public class SysUserList : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";

            AdminHelper.CheckLogin();
            DataTable users = SqlHelper.ExecuteDataTable("select * from T_SysUsers");
            var data = new { Title = "系统用户列表", SysUsers = users.Rows };
            string html = CommonHelper.RenderHtml("Admin/SysUserList.htm", data);
            context.Response.Write(html);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}