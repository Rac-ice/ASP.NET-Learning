﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.SessionState;

namespace HuaGongWeb.Admin
{
    /// <summary>
    /// ProductEdit 的摘要说明
    /// </summary>
    public class ProductEdit : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            AdminHelper.CheckLogin();

            bool isPostBack = !string.IsNullOrEmpty(context.Request["IsPostBack"]);
            string action = context.Request["Action"];
            if (isPostBack)
            {
                if (action == "AddNew")
                {
                    //todo：数据合法性检查（服务器端、客户端都要做）：数据格式合法性
                    //是否为空

                    string name = context.Request["Name"];
                    //
                    long categoryId = Convert.ToInt64(context.Request["CategoryId"]);
                    //获得浏览器上传的文件信息(<input type="file"....)
                    //要设定 enctype="multipart/form-data"
                    HttpPostedFile productImg = context.Request.Files["ProductImage"];
                    //图片要保存到项目的文件夹（子文件夹）下才可以通过web来访问图片
                    //productImg.SaveAs("F:\视频教程\2013年底asp.net公开课\HuaGongWeb\HuaGongWeb\HuaGongWeb\uploadfile");
                    //MapPath可以把一个相对于网站根目录的文件或者文件夹路径
                    //转换为在服务器磁盘上的物理全路径
                    //DateTime.Now.ToString("yyyyMMddHHmmssfffffff")得到当前时间的“年月日小时分秒毫秒格式”
                    //string aaaa = context.Request["ProductImage"];
                    string filename = DateTime.Now.ToString("yyyyMMddHHmmssfffffff") + Path.GetExtension(productImg.FileName);//有bug的，一毫秒内多个人上传多个文件
                    productImg.SaveAs(context.Server.MapPath("~/uploadfile/" + filename));
                    //string fff = context.Server.MapPath("~/uploadfile/" + filename);
                   //用guid来做文件名一定不重复， Guid.NewGuid().ToString()
                    //用文件内容的md5值则也几乎不会重复。
                    string msg = context.Request["Msg"];

                    SqlHelper.ExecuteNonQuery("Insert into T_Products(Name,CategoryId,ImagePath,Msg) values(@Name,@CategoryId,@ImagePath,@Msg)", new SqlParameter("@Name", name), new SqlParameter("@CategoryId", categoryId), new SqlParameter("@ImagePath", "/uploadfile/" + filename), new SqlParameter("@Msg", msg));
                    context.Response.Redirect("ProductList.ashx");
                }
                else if (action == "Edit")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    string name = context.Request["Name"];
                    long categoryId = Convert.ToInt64(context.Request["CategoryId"]);
                    HttpPostedFile productImg = context.Request.Files["ProductImage"];
                    string msg = context.Request["Msg"];

                    if (CommonHelper.HasFile(productImg) )//用户没有选择新图片，那么还用之前的产品图片
                    {
                        string filename = DateTime.Now.ToString("yyyyMMddHHmmssfffffff") + Path.GetExtension(productImg.FileName);//有bug的，一毫秒内多个人上传多个文件
                        productImg.SaveAs(context.Server.MapPath("~/uploadfile/" + filename));

                        SqlHelper.ExecuteNonQuery("Update T_Products set Name=@Name,CategoryId=@CategoryId,Msg=@Msg,ImagePath=@ImagePath where Id=@Id", new SqlParameter("@Name", name)
                            , new SqlParameter("@CategoryId", categoryId), new SqlParameter("@Msg", msg)
                            , new SqlParameter("@ImagePath", "/uploadfile/" + filename), new SqlParameter("@Id", id));
                        context.Response.Redirect("ProductList.ashx");                        
                    }
                    else
                    {
                        SqlHelper.ExecuteNonQuery("Update T_Products set Name=@Name,CategoryId=@CategoryId,Msg=@Msg where Id=@Id", new SqlParameter("@Name", name)
                            , new SqlParameter("@CategoryId", categoryId), new SqlParameter("@Msg", msg)
                            , new SqlParameter("@Id", id));
                        context.Response.Redirect("ProductList.ashx");
                    }
                }
                else
                {
                    context.Response.Write("Action错误："+action);
                }
            }
            else
            {       
                DataTable categories = SqlHelper.ExecuteDataTable("select * from T_ProductCategories");

                if (action == "AddNew")
                {
                    var data = new { Title = "新增产品", Action = action, Product = new { Id = 0, Name = "", CategoryId = 0, Msg = "" }, Categories = categories.Rows };
                    string html = CommonHelper.RenderHtml("Admin/ProductEdit.htm", data);
                    context.Response.Write(html);
                }
                else if (action == "Edit")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    DataTable products = SqlHelper.ExecuteDataTable("select * from T_Products where Id=@Id",new SqlParameter("@Id",id));
                    if (products.Rows.Count <= 0)
                    {
                        context.Response.Write("找不到Id="+id+"的产品");
                    }
                    else if (products.Rows.Count > 1)
                    {
                        context.Response.Write("找到多个Id=" + id + "的产品");
                    }
                    else
                    {
                        DataRow row = products.Rows[0];
                        var data = new { Title = "编辑产品", Action = action, Product = row, Categories = categories.Rows };
                        string html = CommonHelper.RenderHtml("Admin/ProductEdit.htm", data);
                        context.Response.Write(html);
                    }
                }
                else
                {
                    context.Response.Write("Action错误："+action);
                }
            }            
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
