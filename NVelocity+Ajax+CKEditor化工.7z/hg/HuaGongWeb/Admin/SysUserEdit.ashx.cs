﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.SessionState;

namespace HuaGongWeb.Admin
{
    /// <summary>
    /// SysUserEdit 的摘要说明
    /// </summary>
    public class SysUserEdit : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";

            AdminHelper.CheckLogin();

            bool isPostBack = !string.IsNullOrEmpty(context.Request["IsPostBack"]);
            if (isPostBack)
            {
                string action = context.Request["Action"];
                if (action == "AddNew")
                {
                    string name = context.Request["Name"];
                    string realName = context.Request["RealName"];
                    string password = context.Request["Password"];
                    SqlHelper.ExecuteNonQuery("Insert into T_SysUsers(Name,RealName,Password) values(@Name,@RealName,@Password)", new SqlParameter("@Name", name), new SqlParameter("@RealName", realName), new SqlParameter("@Password", password));
                    context.Response.Redirect("SysUserList.ashx");
                }
                else
                {
                    long id = Convert.ToInt32(context.Request["Id"]);
                    string name = context.Request["Name"];
                    string realName = context.Request["RealName"];
                    string password = context.Request["Password"];
                    SqlHelper.ExecuteNonQuery("update T_SysUsers set Name=@Name,RealName=@RealName,Password=@Password where Id=@Id", new SqlParameter("@Name", name), new SqlParameter("@RealName", realName), new SqlParameter("@Password", password), new SqlParameter("@Id", id));
                    context.Response.Redirect("SysUserList.ashx");
                }
            }
            else
            {
                string action = context.Request["Action"];
                if (action == "AddNew")
                {
                    var data = new { Title = "新增系统用户", Action = action, SysUser = new { Id = 0, Name = "",RealName="",Password="" } };
                    string html = CommonHelper.RenderHtml("Admin/SysUserEdit.htm", data);
                    context.Response.Write(html);
                }
                else if (action == "Edit")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    DataTable dt = SqlHelper.ExecuteDataTable("select * from T_SysUsers where Id=@Id", new SqlParameter("@Id", id));
                    if (dt.Rows.Count <= 0)
                    {
                        context.Response.Write("找不到Id=" + id + "的系统用户");
                    }
                    else if (dt.Rows.Count > 1)
                    {
                        context.Response.Write("找到多个Id=" + id + "的系统用户");
                    }
                    else
                    {
                        DataRow row = dt.Rows[0];
                        var data = new { Title = "编辑系统用户", Action = action, SysUser = row };
                        string html = CommonHelper.RenderHtml("Admin/SysUserEdit.htm", data);
                        context.Response.Write(html);
                    }
                }
                else if (action == "Delete")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    SqlHelper.ExecuteNonQuery("Delete from T_SysUsers where Id=@Id", new SqlParameter("@Id", id));
                    context.Response.Redirect("SysUserList.ashx");
                }
                else
                {
                    context.Response.Write("Action错误：" + action);
                }
            }    
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}