﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.SessionState;

namespace HuaGongWeb.Admin
{
    /// <summary>
    /// ProductCategoryEdit 的摘要说明
    /// </summary>
    public class ProductCategoryEdit : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            AdminHelper.CheckLogin();
            bool isPostBack = !string.IsNullOrEmpty(context.Request["IsPostBack"]);
            if (isPostBack)
            {
                string action = context.Request["Action"];
                if (action == "AddNew")
                {
                    string name = context.Request["Name"];
                    SqlHelper.ExecuteNonQuery("Insert into T_ProductCategories(Name) values(@Name)", new SqlParameter("@Name", name));
                    context.Response.Redirect("ProductCategoryList.ashx");
                }
                else
                {
                    long id = Convert.ToInt32(context.Request["Id"]);
                    string name = context.Request["Name"];
                    SqlHelper.ExecuteNonQuery("update T_ProductCategories set Name=@Name where Id=@Id", new SqlParameter("@Name", name), new SqlParameter("@Id", id));
                    context.Response.Redirect("ProductCategoryList.ashx");
                }
            }
            else
            {
                string action = context.Request["Action"];
                if (action == "AddNew")
                {
                    var data = new { Title = "新增产品类别", Action = action, ProductCategory = new { Id=0,Name=""} };
                    string html = CommonHelper.RenderHtml("Admin/ProductCategoryEdit.htm", data);
                    context.Response.Write(html);
                }
                else if (action == "Edit")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    DataTable dt = SqlHelper.ExecuteDataTable("select * from T_ProductCategories where Id=@Id", new SqlParameter("@Id", id));
                    if (dt.Rows.Count <= 0)
                    {
                        context.Response.Write("找不到Id=" + id + "的产品类别");
                    }
                    else if (dt.Rows.Count > 1)
                    {
                        context.Response.Write("找到多个Id=" + id + "的产品类别");
                    }
                    else
                    {
                        DataRow row = dt.Rows[0];
                        var data = new { Title = "编辑产品类别", Action = action, ProductCategory = row};
                        string html = CommonHelper.RenderHtml("Admin/ProductCategoryEdit.htm", data);
                        context.Response.Write(html);
                    }
                }
                else if(action=="Delete")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    SqlHelper.ExecuteNonQuery("Delete from T_ProductCategories where Id=@Id", new SqlParameter("@Id", id));
                    context.Response.Redirect("ProductCategoryList.ashx");
                }
                else
                {
                    context.Response.Write("Action错误：" + action);
                }
            }     
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}