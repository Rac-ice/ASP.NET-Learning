﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.SessionState;

namespace HuaGongWeb.Admin
{
    /// <summary>
    /// ProductCategoryList 的摘要说明
    /// </summary>
    public class ProductCategoryList : IHttpHandler, IRequiresSessionState
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";

            AdminHelper.CheckLogin();

            DataTable dt = SqlHelper.ExecuteDataTable("select * from T_ProductCategories");
            var data = new { Title = "产品类别列表", Categories = dt.Rows };
            string html = CommonHelper.RenderHtml("Admin/ProductCategoryList.htm", data);
            context.Response.Write(html);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}