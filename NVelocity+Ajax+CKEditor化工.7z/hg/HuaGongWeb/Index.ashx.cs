﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace HuaGongWeb
{
    /// <summary>
    /// Index 的摘要说明
    /// </summary>
    public class Index : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            DataTable recommendProducts = SqlHelper.ExecuteDataTable("select * from T_Products where IsRecommend=1");

            var data = new { ProductCategories = CommonHelper.GetProductCategories(), Settings = CommonHelper.GetSettings(), RecommendProducts = recommendProducts.Rows };
            string html = CommonHelper.RenderHtml("Front/Index.htm", data);
            context.Response.Write(html);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}