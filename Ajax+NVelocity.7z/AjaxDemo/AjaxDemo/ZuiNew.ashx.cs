﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AjaxDemo
{
    /// <summary>
    /// ZuiNew 的摘要说明
    /// </summary>
    public class ZuiNew : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            string str = SqlHelper.ExecuteScalar("select top 1 Msg from T_PingLun order by Id desc").ToString();
            context.Response.Write(str);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}