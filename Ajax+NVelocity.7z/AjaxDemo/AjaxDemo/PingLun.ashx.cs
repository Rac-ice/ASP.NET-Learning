﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace AjaxDemo
{
    /// <summary>
    /// PingLun 的摘要说明
    /// </summary>
    public class PingLun : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            string pingLun = context.Request["PingLun"];
            if (pingLun != null)
            {
                int result = SqlHelper.ExecuteNonQuery("insert into T_PingLun(Msg) values(@msg)",new SqlParameter("@msg",pingLun));
                if (result == 1)
                {
                    context.Response.Write("ok");
                }
                else
                {
                    context.Response.Write("no");
                }
            }
            else
            {
                DataTable dt = SqlHelper.ExecuteDataTable("select  * from T_PingLun order by Id desc");
                string html = CommonHelper.RenderHtml("PingLun.htm", dt.Rows);
                context.Response.Write(html);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}