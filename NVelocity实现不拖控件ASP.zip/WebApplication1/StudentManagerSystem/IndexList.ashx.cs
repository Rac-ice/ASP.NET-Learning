﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace StudentManagerSystem
{
    /// <summary>
    /// IndexList 的摘要说明
    /// </summary>
    public class IndexList : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            string type = context.Request["Type"];
            if (type == "TeacherList")
            {
                DataTable dt = SqlHelper.ExecuteDataTable("select * from T_Teachers where isDelete=0");
                var data = new { Type = "TeacherList" ,Teachers=dt.Rows };
                string html = CommonHelper.RenderHtml("IndexList.htm", data);
                context.Response.Write(html);
            }
            else if (type == "StudentList")
            {
                DataTable dt = SqlHelper.ExecuteDataTable("select s.*,c.ClassName from T_Students as s inner join T_Class as c on s.ClassId=c.Id where s.isDelete=0");
                var data = new { Type = "StudentList", Students = dt.Rows };
                string html = CommonHelper.RenderHtml("IndexList.htm", data);
                context.Response.Write(html);
            }
            else if (type == "ClassList")
            {
                DataTable dt = SqlHelper.ExecuteDataTable("select c.*,t.Name from T_Class as c inner join T_Teachers as t on c.TeacherId=t.Id where c.isDelete=0");
                var data = new { Type = "ClassList", Classes = dt.Rows };
                string html = CommonHelper.RenderHtml("IndexList.htm", data);
                context.Response.Write(html);
            }
            else if (type == null)
            {
                string html = CommonHelper.RenderHtml("IndexList.htm", "");
                context.Response.Write(html);
            }
            else
            {
                context.Response.Write("Type参数错误！");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}