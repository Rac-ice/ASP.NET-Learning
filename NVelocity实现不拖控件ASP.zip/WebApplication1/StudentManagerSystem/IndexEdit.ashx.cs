﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace StudentManagerSystem
{
    /// <summary>
    /// IndexEdit 的摘要说明
    /// </summary>
    public class IndexEdit : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            string type = context.Request["Type"];
            if (type=="TeacherList")
            {
                string action = context.Request["Action"];
                if (action == "AddNew")
                {
                    bool save = Convert.ToBoolean(context.Request["Save"]);
                    if (save)
                    {
                        string name = context.Request["Name"];
                        string phone = context.Request["Phone"];
                        string email = context.Request["Email"];
                        DateTime birthday = Convert.ToDateTime(context.Request["Birthday"]);
                        SqlHelper.ExecuteNonQuery("insert into T_Teachers(Name,Phone,Email,Birthday,isDelete) values(@name,@phone,@email,@birthday,0)",new SqlParameter("@name",name),new SqlParameter("@phone",phone),new SqlParameter("@email",email),new SqlParameter("@birthday",birthday));
                        context.Response.Redirect("IndexList.ashx?Type=TeacherList");
                    }
                    else
                    {
                        var data = new { Type="TeacherList", Action = "AddNew", Teachers = new { Name = "", Phone = "", Email = "@123.com" ,Birthday="xxxx-xx-xx"} };
                        string html = CommonHelper.RenderHtml("IndexEdit.htm", data);
                        context.Response.Write(html);
                    }
                }
                else if (action == "Edit")
                {
                    bool save = Convert.ToBoolean(context.Request["Save"]);
                    if (save)
                    {
                        long id = Convert.ToInt64(context.Request["Id"]);
                        string name = context.Request["Name"];
                        string phone = context.Request["Phone"];
                        string email = context.Request["Email"];
                        DateTime birthday = Convert.ToDateTime(context.Request["Birthday"]);
                        SqlHelper.ExecuteNonQuery("update T_Teachers set Name=@name,Phone=@phone,Email=@email,Birthday=@birthday where Id=@id", new SqlParameter("@name", name), new SqlParameter("@phone", phone), new SqlParameter("@email", email), new SqlParameter("@birthday", birthday),new SqlParameter("@id",id));
                        context.Response.Redirect("IndexList.ashx?Type=TeacherList");
                    }
                    else
                    {
                        long id = Convert.ToInt64(context.Request["Id"]);
                        DataTable dt = SqlHelper.ExecuteDataTable("select * from T_Teachers where Id=@id", new SqlParameter("@id", id));
                        if (dt.Rows.Count <= 0)
                        {
                            context.Response.Write("没有找到Id=" + id + "的数据");
                            return;
                        }
                        else if (dt.Rows.Count > 1)
                        {
                            context.Response.Write("找到多条Id=" + id + "的数据");
                        }
                        else
                        {
                            DataRow row = dt.Rows[0];
                            var data = new { Type = "TeacherList", Action = "Edit", Teachers = row };
                            string html = CommonHelper.RenderHtml("IndexEdit.htm", data);
                            context.Response.Write(html);
                        }
                    }
                }
                else if (action == "Delete")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    SqlHelper.ExecuteNonQuery("update T_Teachers set isDelete=1 where Id=@id", new SqlParameter("@id", id));
                    context.Response.Redirect("IndexList.ashx?Type=TeacherList");
                }
                else
                {
                    context.Response.Write("Action参数错误！");
                }
            }
            else if (type == "StudentList")
            {
                string action = context.Request["Action"];
                if (action == "AddNew")
                {
                    bool save = Convert.ToBoolean(context.Request["Save"]);
                    if (save)
                    {
                        string name = context.Request["Name"];
                        string gender = context.Request["Gender"];
                        string birthday = context.Request["Birthday"];
                        string height = context.Request["Height"];
                        long classid = Convert.ToInt64(context.Request["ClassId"]);
                        int specialty;
                        if (context.Request["Specialty"] == "on")
                        {
                            specialty = 1;
                        }
                        else
                        {
                            specialty = 0;
                        }
                        SqlHelper.ExecuteNonQuery("insert into T_Students(Name,Gender,Birthday,Height,ClassId,Specialty,isDelete) values(@name,@gender,@birthday,@height,@classid,@specialty,0)", new SqlParameter("@name", name), new SqlParameter("@gender", gender), new SqlParameter("@birthday", birthday), new SqlParameter("@height", height), new SqlParameter("@classid", classid), new SqlParameter("@specialty", specialty));
                        context.Response.Redirect("IndexList.ashx?Type=StudentList");
                    }
                    else
                    {
                        DataTable dt = SqlHelper.ExecuteDataTable("select * from T_Class where isDelete=0");
                        var data = new { Type = "StudentList", Action = "AddNew", Students = new { Name = "", Gender = "", Birthday = "XXXX-XX-XX", Height = "", ClassId = 0, Specialty = 0 }, Classes = dt.Rows };
                        string html = CommonHelper.RenderHtml("IndexEdit.htm", data);
                        context.Response.Write(html);
                    }
                }
                else if (action == "Edit")
                {
                    bool save = Convert.ToBoolean(context.Request["Save"]);
                    if (save)
                    {
                        long id = Convert.ToInt64(context.Request["Id"]);
                        string name = context.Request["Name"];
                        string gender = context.Request["Gender"];
                        string birthday = context.Request["Birthday"];
                        string height = context.Request["Height"];
                        long classid = Convert.ToInt64(context.Request["ClassId"]);
                        int specialty;
                        if (context.Request["Specialty"] == "on")
                        {
                            specialty = 1;
                        }
                        else
                        {
                            specialty = 0;
                        }
                        SqlHelper.ExecuteNonQuery("update T_Students set Name=@name,Gender=@gender,Birthday=@birthday,Height=@height,ClassId=@classid,Specialty=@specialty where Id=@id", new SqlParameter("@name", name), new SqlParameter("@gender", gender), new SqlParameter("@birthday", birthday), new SqlParameter("@height", height), new SqlParameter("@classid", classid), new SqlParameter("@specialty", specialty), new SqlParameter("@id", id));
                        context.Response.Redirect("IndexList.ashx?Type=StudentList");
                    }
                    else
                    {
                        long id = Convert.ToInt64(context.Request["Id"]);
                        DataTable dt = SqlHelper.ExecuteDataTable("select * from T_Students where Id=@id", new SqlParameter("@id", id));
                        if (dt.Rows.Count <= 0)
                        {
                            context.Response.Write("没有找到Id=" + id + "的数据");
                            return;
                        }
                        else if (dt.Rows.Count > 1)
                        {
                            context.Response.Write("找到多条Id=" + id + "的数据");
                        }
                        else
                        {
                            DataTable dtClasses = SqlHelper.ExecuteDataTable("select * from T_Class where isDelete=0");
                            DataRow row = dt.Rows[0];
                            var data = new { Type = "StudentList", Action = "Edit", Students = row, Classes = dtClasses.Rows };
                            string html = CommonHelper.RenderHtml("IndexEdit.htm", data);
                            context.Response.Write(html);
                        }
                    }
                }
                else if (action == "Delete")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    SqlHelper.ExecuteNonQuery("update T_Students set isDelete=1 where Id=@id", new SqlParameter("@id", id));
                    context.Response.Redirect("IndexList.ashx?Type=StudentList");
                }
                else
                {
                    context.Response.Write("Action参数错误！");
                }
            }
            else if (type == "ClassList")
            {
                string action = context.Request["Action"];
                if (action == "AddNew")
                {
                    bool save = Convert.ToBoolean(context.Request["Save"]);
                    if (save)
                    {
                        string classname = context.Request["ClassName"];
                        int roomid = Convert.ToInt32(context.Request["RoomId"]);
                        long teacherid = Convert.ToInt64(context.Request["TeacherId"]);
                        SqlHelper.ExecuteNonQuery("insert into T_Class(ClassName,RoomId,TeacherId,isDelete) values(@classname,@roomid,@teacherid,0)", new SqlParameter("@classname", classname), new SqlParameter("@roomid", roomid), new SqlParameter("@teacherid", teacherid));
                        context.Response.Redirect("IndexList.ashx?Type=ClassList");
                    }
                    else
                    {
                        DataTable dt = SqlHelper.ExecuteDataTable("select * from T_Teachers where isDelete=0");
                        var data = new { Type = "ClassList", Action = "AddNew", Classes = new { ClassName = "X年X班" ,RoomId=0} ,Teachers=dt.Rows};
                        string html = CommonHelper.RenderHtml("IndexEdit.htm", data);
                        context.Response.Write(html);
                    }
                }
                else if (action == "Edit")
                {
                    bool save = Convert.ToBoolean(context.Request["Save"]);
                    if (save)
                    {
                        long id = Convert.ToInt64(context.Request["Id"]);
                        string classname = context.Request["ClassName"];
                        int roomid = Convert.ToInt32(context.Request["RoomId"]);
                        long teacherid = Convert.ToInt64(context.Request["TeacherId"]);
                        SqlHelper.ExecuteNonQuery("update T_Class set ClassName=@classname,RoomId=@roomid,TeacherId=@teacherid where Id=@id", new SqlParameter("@classname", classname), new SqlParameter("@roomid", roomid), new SqlParameter("@teacherid", teacherid), new SqlParameter("@id", id));
                        context.Response.Redirect("IndexList.ashx?Type=ClassList");
                    }
                    else
                    {
                        long id = Convert.ToInt64(context.Request["Id"]);
                        DataTable dt = SqlHelper.ExecuteDataTable("select * from T_Class where Id=@id", new SqlParameter("@id", id));
                        if (dt.Rows.Count <= 0)
                        {
                            context.Response.Write("没有找到Id=" + id + "的数据");
                            return;
                        }
                        else if (dt.Rows.Count > 1)
                        {
                            context.Response.Write("找到多条Id=" + id + "的数据");
                        }
                        else
                        {
                            DataTable dtTeachers = SqlHelper.ExecuteDataTable("select * from T_Teachers where isDelete=0");
                            DataRow row = dt.Rows[0];
                            var data = new { Type = "ClassList", Action = "Edit", Classes = row, Teachers = dtTeachers.Rows };
                            string html = CommonHelper.RenderHtml("IndexEdit.htm", data);
                            context.Response.Write(html);
                        }
                    }
                }
                else if (action == "Delete")
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    SqlHelper.ExecuteNonQuery("update T_Class set isDelete=1 where Id=@id", new SqlParameter("@id", id));
                    context.Response.Redirect("IndexList.ashx?Type=ClassList");
                }
                else
                {
                    context.Response.Write("Action参数错误！");
                }
            }
            else
            {
                context.Response.Write("Type参数错误！");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}