﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace CRUDTest1
{
    /// <summary>
    /// PersonEdit 的摘要说明
    /// </summary>
    public class PersonEdit : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            //PersonEdit.ashx?action=AddNew
            //PersonEdit.ashx?action=Edit&Id=3
            string action = context.Request["Action"];
            if (action == "AddNew")
            {
                //判断是否含有Save并且等于true，如果是的话说明是点击【保存】按钮请求来的
                bool save = Convert.ToBoolean(context.Request["Save"]);
                if (save)//是保存
                {
                    string name = context.Request["Name"];
                    int age = Convert.ToInt32(context.Request["Age"]);
                    string email = context.Request["Email"];
                    long classid = Convert.ToInt64(context.Request["ClassId"]);
                    SqlHelper.ExecuteNonQuery("insert into T_Persons(Name,Age,Email,ClassId) values(@name,@age,@email,@classid)",new SqlParameter("@name",name),new SqlParameter("@age",age),new SqlParameter("@email",email),new SqlParameter("@classid",classid
));
                    context.Response.Redirect("PersonList.ashx");//保存成功返回列表页面
                }
                else
                {
                    DataTable dt =  SqlHelper.ExecuteDataTable("select * from T_Classes");
                    var data = new { Action = "AddNew", Person = new { Name = "", Age = 20, Email = "@123.com" } ,Classes=dt.Rows};
                    string html = CommonHelper.RenderHtml("PersonEdit.htm", data);
                    context.Response.Write(html);
                }
            }
            else if (action == "Edit")
            {
                bool save = Convert.ToBoolean(context.Request["Save"]);
                if (save)
                {
                    //所有的信息都尽量不要在服务器端“记忆”，尽量通过客户端传递
                    //服务器是一个无状态，服务器只认识Request中的信息
                    long id = Convert.ToInt64(context.Request["Id"]);
                    string name = context.Request["Name"];
                    int age = Convert.ToInt32(context.Request["Age"]);
                    string email = context.Request["Email"];
                    long classid = Convert.ToInt64(context.Request["ClassId"]);
                    SqlHelper.ExecuteNonQuery("update T_Persons set Name=@name,Age=@age,Email=@email,ClassId=@classid where Id=@id", new SqlParameter("@name", name), new SqlParameter("@age", age), new SqlParameter("@email", email),new SqlParameter("@classid",classid),new SqlParameter("@id",id));
                    context.Response.Redirect("PersonList.ashx");//保存成功返回列表页面
                }
                else
                {
                    long id = Convert.ToInt64(context.Request["Id"]);
                    DataTable dt = SqlHelper.ExecuteDataTable("select * from T_Persons where Id=@id",new SqlParameter("@id",id));
                    if (dt.Rows.Count <= 0)
                    {
                        context.Response.Write("没有找到Id=" + id + "的数据");
                        return;
                    }
                    else if (dt.Rows.Count > 1)
                    {
                        context.Response.Write("找到多条Id=" + id + "的数据");
                    }
                    else
                    {
                        DataTable dtClasses = SqlHelper.ExecuteDataTable("select * from T_Classes");
                        DataRow row = dt.Rows[0];
                        var data = new { Action = "Edit", Person = row ,Classes=dtClasses.Rows};
                        string html = CommonHelper.RenderHtml("PersonEdit.htm",data);
                        context.Response.Write(html);
                    }
                }
            }
            else if(action == "Delete")
            {
                long id = Convert.ToInt64(context.Request["Id"]);
                SqlHelper.ExecuteNonQuery("delete from T_Persons where Id=@id",new SqlParameter("@id",id));
                context.Response.Redirect("PersonList.ashx");
            }
            else
            {
                context.Response.Write("Action参数错误！");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}