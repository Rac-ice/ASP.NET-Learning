﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NVelocity.App;
using NVelocity.Runtime;
using NVelocity;

namespace WebApplication1
{
    /// <summary>
    /// Login 的摘要说明
    /// </summary>
    public class Login : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            string name = context.Request["name"];
            string pwd = context.Request["pwd"];
            if (string.IsNullOrEmpty(name) && string.IsNullOrEmpty(pwd))
            {
                VelocityEngine vltEngine = new VelocityEngine();
                vltEngine.SetProperty(RuntimeConstants.RESOURCE_LOADER, "file");
                vltEngine.SetProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, System.Web.Hosting.HostingEnvironment.MapPath("~/templates"));
                vltEngine.Init();
                VelocityContext vltContext = new VelocityContext();
                vltContext.Put("name", "");
                vltContext.Put("pwd", "");
                vltContext.Put("msg", "");
                Template vltTemplate = vltEngine.GetTemplate("login.htm");
                System.IO.StringWriter vltWrite = new System.IO.StringWriter();
                vltTemplate.Merge(vltContext, vltWrite);
                string html = vltWrite.GetStringBuilder().ToString();
                context.Response.Write(html);
            }
            else
            {
                if (name == "admin" && pwd == "123")
                {
                    context.Response.Write("登录成功");
                }
                else
                {
                    VelocityEngine vltEngine = new VelocityEngine();
                    vltEngine.SetProperty(RuntimeConstants.RESOURCE_LOADER, "file");
                    vltEngine.SetProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, System.Web.Hosting.HostingEnvironment.MapPath("~/templates"));
                    vltEngine.Init();
                    VelocityContext vltContext = new VelocityContext();
                    vltContext.Put("name", name);
                    vltContext.Put("pwd", pwd);
                    vltContext.Put("msg", "用户名或密码错误");
                    Template vltTemplate = vltEngine.GetTemplate("login.htm");
                    System.IO.StringWriter vltWrite = new System.IO.StringWriter();
                    vltTemplate.Merge(vltContext, vltWrite);
                    string html = vltWrite.GetStringBuilder().ToString();
                    context.Response.Write(html);
                }
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}