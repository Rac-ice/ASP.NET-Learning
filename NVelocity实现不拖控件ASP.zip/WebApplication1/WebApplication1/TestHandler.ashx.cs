﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{
    /// <summary>
    /// TestHandler 的摘要说明
    /// </summary>
    public class TestHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            string name = context.Request["name"];
            string age = context.Request["age"];
            context.Response.Write("<font color='red'>Hello World，" + name + "</font><br/>");
            context.Response.Write("<font color='green'>Age：" + age + "</font>");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}