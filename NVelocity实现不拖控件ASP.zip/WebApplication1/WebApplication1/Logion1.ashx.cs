﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NVelocity.App;
using NVelocity.Runtime;
using NVelocity;

namespace WebApplication1
{
    /// <summary>
    /// Logion1 的摘要说明
    /// </summary>
    public class Logion1 : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/html";
            Person person = new Person();
            person.Name = "wpj"; 
            person.Age = 18;
            Person dad = new Person();
            dad.Name = "wmh";
            dad.Age = 50;
            person.Father = dad;
            VelocityEngine vltEngine = new VelocityEngine();
            vltEngine.SetProperty(RuntimeConstants.RESOURCE_LOADER, "file");
            vltEngine.SetProperty(RuntimeConstants.FILE_RESOURCE_LOADER_PATH, System.Web.Hosting.HostingEnvironment.MapPath("~/templates"));
            vltEngine.Init();
            VelocityContext vltContext = new VelocityContext();
            vltContext.Put("p", person);
            Template vltTemplate = vltEngine.GetTemplate("test.htm");
            System.IO.StringWriter vltWrite = new System.IO.StringWriter();
            vltTemplate.Merge(vltContext, vltWrite);
            string html = vltWrite.GetStringBuilder().ToString();
            context.Response.Write(html);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}